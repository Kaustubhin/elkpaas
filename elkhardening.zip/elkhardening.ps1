Configuration elkhardening {
param
    (
    # Target nodes to apply the configuration
    [string[]]$NodeName = 'localhost'
    )
# Import the module that defines custom resources
Import-DscResource -ModuleName xPSDesiredStateConfiguration
Node $NodeName
{
    Registry 'DisableRunAs' {
        Ensure    = 'Present'
        Key       = 'HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\WinRM\Service'
        ValueName = 'DisableRunAs'
        ValueType = 'DWord'
        ValueData = '1'
    }
    WindowsFeature 'Telnet-Client' {
        Name   = 'Telnet-Client'
        Ensure = 'Present'
    }
    Registry 'AdmPwdEnabled' {
        Ensure    = 'Present'
        Key       = 'HKEY_LOCAL_MACHINE\Software\Policies\Microsoft Services\AdmPwd'
        ValueName = 'AdmPwdEnabled'
        ValueType = 'DWord'
        ValueData = '1'
    }

    }
    Script TurnOffFirewall
    {
      GetScript = {@{}}
      TestScript = {
        $Result = Get-NetFirewallProfile | Where-Object {$_.Enabled -eq $True}
        if($Result) { Return $False } else { Return $True }
      }
      SetScript = {
        Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
      }
    }
}
